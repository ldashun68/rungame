window.loadLib = require;
loadLib("laya.core.js")
loadLib("laya.ui.js")
loadLib("laya.physics3D.js")
loadLib("laya.d3.js")
loadLib("laya.ani.js")
loadLib("bundle.js")